from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import uuid


# =========================================================
# SMART PRESCRIPTION READER
# Backend - Flask API
# =========================================================


app = Flask(__name__)

# Allow frontend to communicate with backend
CORS(app)


# =========================================================
# CONFIGURATION
# =========================================================

UPLOAD_FOLDER = "uploads"

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# Create uploads folder if it does not exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# =========================================================
# HOME / TEST ROUTE
# =========================================================

@app.route("/", methods=["GET"])
def home():

    return jsonify({
        "success": True,
        "message": "Smart Prescription Reader API is running"
    })


# =========================================================
# API STATUS
# =========================================================

@app.route("/api/status", methods=["GET"])
def status():

    return jsonify({
        "success": True,
        "status": "online",
        "project": "Smart Prescription Reader"
    })


# =========================================================
# ANALYZE PRESCRIPTION
# =========================================================

@app.route("/api/analyze", methods=["POST"])
def analyze_prescription():

    # Check whether image was uploaded
    if "prescription" not in request.files:

        return jsonify({
            "success": False,
            "message": "No prescription image was uploaded"
        }), 400


    file = request.files["prescription"]


    # Check filename
    if file.filename == "":

        return jsonify({
            "success": False,
            "message": "No file selected"
        }), 400


    # Create unique filename
    extension = os.path.splitext(
        file.filename
    )[1]

    filename = (
        str(uuid.uuid4())
        + extension
    )


    filepath = os.path.join(
        app.config["UPLOAD_FOLDER"],
        filename
    )


    # Save uploaded image
    file.save(filepath)


    # =====================================================
    # TEMPORARY RESPONSE
    # =====================================================
    #
    # OCR / CNN / NLP / MLP will be connected here later.
    #

    result = {

        "medicine": "Pending AI Recognition",

        "dosage": "Pending AI Recognition",

        "frequency": "Pending AI Recognition",

        "duration": "Pending AI Recognition",

        "instructions": "Pending AI Recognition",

        "raw_text": "Prescription image uploaded successfully."

    }


    return jsonify({

        "success": True,

        "message": "Prescription image uploaded successfully",

        "filename": filename,

        "result": result

    })


# =========================================================
# RUN SERVER
# =========================================================

if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )