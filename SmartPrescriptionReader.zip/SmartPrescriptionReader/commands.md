* for backend:

python --version

python -m venv venv

.\\venv\\Scripts\\Activate.ps1  (or) venv\\Scripts\\activate.bat



* with (venu) c:\\.........\\ 

pip install flask flask-cors

pip show flask



* after code app.py : python app.py

\[ \* Serving Flask app 'app'

\* Debug mode: on

\* Running on http://127.0.0.1:5000 



run that on browser

]







