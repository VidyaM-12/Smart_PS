/* =========================================================
   SMART PRESCRIPTION READER
   Result Page JavaScript
   ========================================================= */


/* =========================
   LOAD PRESCRIPTION IMAGE
   ========================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const image =
            document.getElementById(
                "resultPrescriptionImage"
            );

        const placeholder =
            document.getElementById(
                "resultImagePlaceholder"
            );


        /*
         * Retrieve the image saved on
         * the Reader page.
         */

        const savedImage =
            sessionStorage.getItem(
                "prescriptionImage"
            );


        if (savedImage) {

            image.src = savedImage;

            image.style.display = "block";

            placeholder.style.display = "none";

        } else {

            image.style.display = "none";

            placeholder.style.display = "flex";

        }

    }
);


/* =========================
   READ PRESCRIPTION ALOUD
   ========================= */

function readPrescription() {

    const text =
        "Prescription results. " +
        "Medicine one: Paracetamol, 500 milligrams, twice daily, for 5 days, after food. " +
        "Medicine two: Cetirizine, 10 milligrams, once daily, for 3 days.";


    if ("speechSynthesis" in window) {

        window.speechSynthesis.cancel();

        const speech =
            new SpeechSynthesisUtterance(text);

        speech.rate = 0.9;

        speech.pitch = 1;

        window.speechSynthesis.speak(
            speech
        );

    } else {

        alert(
            "Text-to-speech is not supported by this browser."
        );

    }
}


/* =========================
   TRANSLATION
   ========================= */

function translatePrescription() {

    alert(
        "Translation feature will be connected later."
    );

}


/* =========================
   EDIT RESULTS
   ========================= */

function editPrescription() {

    alert(
        "Editable prescription results will be added later."
    );

}


/* =========================
   SAVE RESULT
   ========================= */

function downloadResult() {

    alert(
        "Save/Download functionality will be connected after the backend is added."
    );

}