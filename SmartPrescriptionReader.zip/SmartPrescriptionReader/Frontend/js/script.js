/* =========================================================
   SMART PRESCRIPTION READER
   Home Page JavaScript
   ========================================================= */


/* =========================
   PAGE LOAD
   ========================= */

document.addEventListener("DOMContentLoaded", function () {

    console.log("SmartRx Home Page Loaded");

    setupUploadButton();

    setupCameraButton();

    setupSmoothNavigation();

});


/* =========================
   UPLOAD BUTTON
   ========================= */

function setupUploadButton() {

    const uploadButton =
        document.querySelector(".upload-btn");

    if (!uploadButton) {
        return;
    }


    uploadButton.addEventListener(
        "click",
        function () {

            window.location.href =
                "reader.html";

        }
    );

}


/* =========================
   CAMERA BUTTON
   ========================= */

function setupCameraButton() {

    const cameraButton =
        document.querySelector(".camera-btn");

    if (!cameraButton) {
        return;
    }


    cameraButton.addEventListener(
        "click",
        function () {

            window.location.href =
                "reader.html";

        }
    );

}


/* =========================
   SMOOTH NAVIGATION
   ========================= */

function setupSmoothNavigation() {

    const navigationLinks =
        document.querySelectorAll(
            ".navbar nav a"
        );


    navigationLinks.forEach(
        function (link) {

            link.addEventListener(
                "click",
                function () {

                    console.log(
                        "Navigating to:",
                        this.getAttribute("href")
                    );

                }
            );

        }
    );

}


/* =========================
   SCROLL TO FEATURES
   ========================= */

function scrollToFeatures() {

    const featureSection =
        document.getElementById(
            "features"
        );


    if (featureSection) {

        featureSection.scrollIntoView({
            behavior: "smooth"
        });

    }

}


/* =========================
   SHOW INFORMATION
   ========================= */

function showInfo(message) {

    alert(message);

}